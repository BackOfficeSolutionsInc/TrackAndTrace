# ep_fileupload_aws
File upload plugin for Etherpad Lite. A user can upload a file, and a link to the uploaded file is automatically inserted in the pad.
