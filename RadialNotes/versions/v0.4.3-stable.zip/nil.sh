echo "Called"  >> /var/radial/start.log
read -p "waiting..."