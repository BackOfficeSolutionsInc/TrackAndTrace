===========CONTAINS SENSITIVE DATA===========
.ebextensions/03_settings_file.config
 > IAM keys for uploading to the notes server space
 
ssl/*
 > Contains ssl certificates.
 
 
To update servers:
 1. Create a zip of the contents of this directory
 2. Upload using Elastic Beanstalk (increment version number)
 3. Deploy
 
Log files are stored at:
 /var/radial/start.log		=Initialization logs
 /var/radial/exe.log		=Execution logs
 
 
To restart the server manually:
 /home/ec2-user/start.sh