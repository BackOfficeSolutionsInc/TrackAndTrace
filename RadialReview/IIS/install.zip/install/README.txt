use the .ebextensions  "source:" command to download this folder into c:\install

use the .ebextensions "command:" to run all installers